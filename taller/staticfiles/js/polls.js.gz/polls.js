(function() {
    const form = document.querySelector('#quiz-form');
    const checkboxes = form.querySelectorAll('input[type=checkbox]');
    const checkboxLength = checkboxes.length;
    const firstCheckbox = checkboxLength > 0 ? checkboxes[0] : null;

    function init() {
        if (firstCheckbox) {
            for (let i = 0; i < checkboxLength; i++) {
                checkboxes[i].addEventListener('change', checkValidity);
            }

            checkValidity();
        }
    }

    function isChecked() {
        for (let i = 0; i < checkboxLength; i++) {
            if (checkboxes[i].checked) return true;
        }

        return false;
    }

    function checkValidity() {
        const errorMessage = !isChecked() ? 'Selecciona al menos una de las opciones.' : '';
        firstCheckbox.setCustomValidity(errorMessage);
    }

    init();
})();

if (document.contains(document.getElementById("django-message"))) {
            document.getElementById("submit").remove();
            window.scrollTo(0,document.body.scrollHeight);
    } ;

